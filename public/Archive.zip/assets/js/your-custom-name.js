$(document).ready(function() {
			$('#example').DataTable();
			$("div.dataTables_filter input").focus();
		  } );